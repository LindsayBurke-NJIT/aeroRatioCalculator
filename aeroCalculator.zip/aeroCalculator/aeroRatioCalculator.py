"""
Author: Lindsay Burke
Date: 7/15/2023
Description: Calculator for vertical/horizontal tail volume ratio and taper/aspect ratio
"""

from tkinter import *
from tkinter import ttk

#root config
root = Tk()
root.title("NJIT Flylanders Ratio Calculator")
canvas = Canvas()
root.geometry('500x525')
root.resizable(False, False)

#Change color/font styles here
colorSelection = "lightskyblue"
bgThickness = 15
fontName = "Times"

try:
    photo = PhotoImage(file = "njitLogo.png")
    root.iconphoto(False, photo)
except:
    pass

#Tab style
myTheme = ttk.Style()
myTheme.theme_create( "myTheme", settings={
        "TNotebook": {"configure": {"tabmargins": [0, 4, 0, 0]}},
        "TNotebook.Tab": {"configure": {"padding": [5, 5]}}
        })
myTheme.theme_use("myTheme")
tabControl = ttk.Notebook(root)

#Tab configurations
tab1 = Frame(tabControl, width=500, height=550, bg=colorSelection)
tab2 = Frame(tabControl, width=500, height=550, bg=colorSelection)

tabControl.add(tab1, text ='Volume Ratio', state=NORMAL)
tabControl.add(tab2, text ='Aspect/Taper Ratio', state=NORMAL)
tabControl.grid(column=0, row=0, sticky='nsew')

root.configure(bg=colorSelection)


"""
Tab1 -- Volume Ratio
"""
def submitDrop():
    '''This function adds the proper labels and input boxes 
    based on whether horizontal or vertical stabilizer was selected
    '''
    if(clicked.get()=="Horizontal"):
        global chordLabel, chordInput,tailLabel,tailInput,lengthLabel,lengthInput, vTailInput, vTailLabel, wingSpanLabel, wingSpanInput, vLengthLabel, vLengthInput
        #Chord field entry
        chordLabel = Label(tab1, text="Mean Aerodynamic \nChord", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        chordLabel.grid(row=4,column=0) 
        chordInput = Entry(tab1)
        chordInput.grid(row=4, column=1)
        
        #Horizontal tail area field entry
        tailLabel = Label(tab1, text="Horizontal Tail \nArea", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        tailLabel.grid(row=5,column=0)
        tailInput = Entry(tab1)
        tailInput.grid(row=5, column=1)

        #Length field entry
        lengthLabel = Label(tab1, text="Length between aerodynamic centers \nof the wing and horizontal tailplane", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        lengthLabel.grid(row=6,column=0, padx=10) 
        lengthInput = Entry(tab1)
        lengthInput.grid(row=6, column=1)
    else:
        #Vertical wing area field entry
        vTailLabel = Label(tab1, text="Vertical Tail Area", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        vTailLabel.grid(row=4,column=0, padx=10)
        vTailInput = Entry(tab1)
        vTailInput.grid(row=4, column=1)

        #Wing span field entry
        wingSpanLabel = Label(tab1, text="Wing Span", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        wingSpanLabel.grid(row=5, column=0, padx=10)
        wingSpanInput = Entry(tab1)
        wingSpanInput.grid(row=5, column=1)

        #Length field entry
        vLengthLabel = Label(tab1, text="Length between aerodynamic centers \nof the wing and vertical tailplane", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
        vLengthLabel.grid(row=6,column=0, padx=10) 
        vLengthInput = Entry(tab1)
        vLengthInput.grid(row=6, column=1)

def resetAll():
    '''This function clears all input boxes
    '''
    if(clicked.get()=="Horizontal"):
        tailInput.delete(0,"end")
        lengthInput.delete(0,"end")
        wingInput.delete(0,"end")
        chordInput.delete(0,"end")
    elif(clicked.get()=="Vertical"):
        vTailInput.delete(0,"end")
        wingSpanInput.delete(0,"end")
        vLengthInput.delete(0,"end")
        wingInput.delete(0,"end")

def clearOutput():
    outputBox.configure(state=NORMAL)
    outputBox.delete("1.0", "end")
    outputBox.configure(state=DISABLED)

def setValues():
    '''This function takes user entered values from the input boxes
    and assigns to vars for ease of calculations
    '''
    try:
        global wingArea,chord,tailArea,myLength,vTailArea,vLength,wingSpan
        if(clicked.get()=="Horizontal"):
            wingArea = float(wingInput.get())
            chord = float(chordInput.get())
            tailArea = float(tailInput.get())
            myLength = float(lengthInput.get())
        if(clicked.get()=="Vertical"):
            vTailArea = float(vTailInput.get())
            vLength = float(vLengthInput.get())
            wingSpan = float(wingSpanInput.get())
            wingArea = float(wingInput.get())
    except ValueError:
        outputBox.configure(state=NORMAL)
        outputBox.insert("1.0", "Error: Incorrect number format\n")
        outputBox.configure(state=DISABLED)

def submitAll():
    '''Calculates volume ratio and outputs calculation to widget
    '''
    setValues()
    try:
        if(clicked.get()=="Horizontal"):
            outputBox.configure(state=NORMAL)
            volumeRatio = (tailArea*myLength)/(wingArea*chord) #Calculates the volume ratio for horizontal stabilizer
            outputBox.insert("1.0", str(volumeRatio) + '\n')
            outputBox.configure(state=DISABLED)
            return (tailArea*myLength)/(wingArea*chord)
        elif(clicked.get()=="Vertical"):
            outputBox.configure(state=NORMAL)
            outputBox.insert("1.0", str((vTailArea*vLength)/(wingArea*wingSpan)) + '\n') #Calculates the volume ratio for vertical stabilizer
            outputBox.configure(state=DISABLED)
            return (vTailArea*vLength)/(wingArea*wingSpan)
    except ZeroDivisionError:
        outputBox.configure(state=NORMAL)
        outputBox.insert("1.0", "Error: Division by Zero\n")
        outputBox.configure(state=DISABLED)
    except ValueError:
        outputBox.configure(state=NORMAL)
        outputBox.insert("1.0", "Error: Incorrect number format\n")
        outputBox.configure(state=DISABLED)

#Creates dropdown menu
options = ["Horizontal", "Vertical"]
clicked = StringVar()
clicked.set("Horizontal")
dropText = Label(tab1, text="Select Stabilizer Type:", bg=colorSelection,font=fontName+' 15 bold')
dropText.grid(row=1, column=0, pady=10, columnspan=3)
dropDown = OptionMenu(tab1, clicked, *options)
dropDown.grid(row=2, columnspan=3)

#Chord field entry
chordLabel = Label(tab1, text="Mean Aerodynamic \nChord", bg=colorSelection,  highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
chordLabel.grid(row=4,column=0, padx=10) 
chordInput = Entry(tab1)
chordInput.grid(row=4, column=1)
        
#Horizontal tail area field entry
tailLabel = Label(tab1, text="Horizontal Tail \nArea", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
tailLabel.grid(row=5,column=0, padx=10) 
tailInput = Entry(tab1)
tailInput.grid(row=5, column=1)

#Length field entry
lengthLabel = Label(tab1, text="Length between aerodynamic centers \nof the wing and horizontal tailplane", bg=colorSelection, highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
lengthLabel.grid(row=6,column=0, padx=10) 
lengthInput = Entry(tab1)
lengthInput.grid(row=6, column=1)

#Wing area field entry
wingLabel = Label(tab1, text="Wing Area", bg=colorSelection,highlightcolor=colorSelection, highlightbackground=colorSelection, highlightthickness=bgThickness, font=fontName+" 12 bold")
wingLabel.grid(row=3,column=0, padx=10)
wingInput = Entry(tab1)
wingInput.grid(row=3, column=1)
    
#Output box setup
outputLabel = Label(tab1, text="Volume Ratio:", bg="grey", font=fontName+" 13 bold")
outputLabel.grid(row=8, column=1, pady=(10,0))
outputBox = Text(tab1, width=20, height=5, font=fontName+" 13")
outputBox.grid(row=9, column=1, padx=(10,0), sticky='w')
outputBox.configure(state=DISABLED)

#Defines all buttons
dropButton = Button(tab1, text="Select", command=submitDrop, width=6, height=1, bg="cornflowerblue", font=fontName+" 8")
dropButton.grid(row=2, column=1, columnspan=2)

startButton = Button(tab1, text="Calculate", command=submitAll, width=7, height=2, bg="greenyellow", font=fontName, relief="sunken")
startButton.grid(sticky='nw', row=9, column=0, padx=(23,0))

resetButton = Button(tab1, text="Clear \nInput", command=resetAll, width=7, height=2, bg="cornflowerblue", font=fontName, relief="sunken")
resetButton.grid(sticky="ne", row=9, column=0)

clearOutputButton = Button(tab1, text="Clear \nOutput", command=clearOutput, width=7, height=2, bg="cornflowerblue", font=fontName, relief="sunken")
clearOutputButton.grid(sticky='n', row=9, column=0,padx=(13,0))


"""
Tab2 -- Aspect/Taper Ratio
"""
def setVals():
    '''This function sets the values of variables from input boxes
    '''
    global rtChord, tipChord, span, tipChordInput, rootChordInput, spanInput
    try:
        tipChord = float(tipChordInput.get())
        span = float(spanInput.get())
        rtChord = float(rootChordInput.get())
    except ValueError:
        errorInput.configure(state=NORMAL)
        errorInput.insert("1.0", "Please enter numerical values only\n")
        errorInput.configure(state=DISABLED)
    except TypeError:
        errorInput.configure(state=NORMAL)
        errorInput.insert("1.0", "Please enter numerical values only\n")
        errorInput.configure(state=DISABLED)

def calcArea():
    global area
    areaInput.configure(state=NORMAL)
    area = (span*(tipChord+rtChord)/2) #Calculates area
    areaInput.insert("1.0", str(area)+"\n")
    areaInput.configure(state=DISABLED)

def calcAsptRatio():
    try:
        aspectInput.configure(state=NORMAL)
        asptRatio = ((span**2)/area) #Calculates aspect ratio
        aspectInput.insert("1.0", str(asptRatio)+"\n")
        aspectInput.configure(state=DISABLED)
    except ZeroDivisionError:
        errorInput.configure(state=NORMAL)
        errorInput.insert("1.0", "Area cannot be equal to zero.\n")
        errorInput.configure(state=DISABLED)

def calcTprRatio():
    try:
        taperInput.configure(state=NORMAL)
        tprRatio = (tipChord/rtChord) #Calculates taper ratio
        taperInput.insert("1.0", str(tprRatio)+"\n")
        taperInput.configure(state=DISABLED)
    except ZeroDivisionError:
        errorInput.configure(state=NORMAL)
        errorInput.insert("1.0", "Root chord cannot be equal to zero.\n")
        errorInput.configure(state=DISABLED)

def clearError():
    errorInput.configure(state=NORMAL)
    errorInput.delete("1.0", END)
    errorInput.configure(state=DISABLED)

def calcAll():
    clearError()
    setVals()
    calcArea()
    calcAsptRatio()
    calcTprRatio()

#Defines all labels, buttons, and input boxes
ttlLabel = Label(tab2, text="Aspect Ratio, Area, and Taper Ratio Calculator\n", bg=colorSelection, font=fontName+" 15 bold", justify=CENTER).grid(row=0, column=0,columnspan=4)

tipChordLabel = Label(tab2, text="Tip Chord", bg=colorSelection, font=fontName+" 13 bold").grid(row=1, column=2)
tipChordInput = Entry(tab2)
tipChordInput.grid(row=1, column=3)

rootChordLabel = Label(tab2, text="Root Chord", bg=colorSelection, font=fontName+" 13 bold").grid(row=2, column=2)
rootChordInput = Entry(tab2)
rootChordInput.grid(row=2, column=3)

spanLabel = Label(tab2, text="Span", bg=colorSelection, font=fontName+" 13 bold").grid(row=3, column=2)
spanInput = Entry(tab2)
spanInput.grid(row=3, column=3)

startButton2 = Button(tab2, text="Calculate", command=calcAll, width=7, height=1, bg="cornflowerblue", font=fontName, relief="sunken")
startButton2.grid(row=4,column=2,columnspan=2, pady=(5,60))

areaLabel = Label(tab2, text="Wing Area", bg=colorSelection, font=fontName+" 13 bold").grid(row=5, column=2)
areaInput = Text(tab2, state=DISABLED, width=15, height=1)
areaInput.grid(row=5, column=3)

aspectLabel = Label(tab2, text="Aspect Ratio", bg=colorSelection, font=fontName+" 13 bold").grid(row=6, column=2)
aspectInput = Text(tab2, state=DISABLED, width=15, height=1)
aspectInput.grid(row=6, column=3)

taperLabel = Label(tab2, text="Taper Ratio", bg=colorSelection, font=fontName+" 13 bold").grid(row=7, column=2)
taperInput = Text(tab2, state=DISABLED, width=15, height=1)
taperInput.grid(row=7, column=3)

errorLabel = Label(tab2, text="Error Log", bg=colorSelection, font=fontName+" 13 bold").grid(row=8, column=2, columnspan=2, pady=(70, 0))
errorInput = Text(tab2, state=DISABLED, width=20, height = 5, fg="red")
errorInput.grid(row=9, column=2, columnspan=2)

root.mainloop()